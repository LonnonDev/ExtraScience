
local NewSciencePacks = {
    "automation-science-pack",
    "ballistics-science-pack-mk1",
    "ballistics-science-pack-mk2",
    "logistic-science-pack",
    "military-science-pack",
    "chemical-science-pack",
    "production-science-pack",
    "utility-science-pack",
    "space-science-pack",
  }


data.raw["lab"]["lab"].inputs = NewSciencePacks