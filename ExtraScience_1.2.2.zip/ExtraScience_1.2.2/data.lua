Files = {"ballistics", "combustion"}
FilesLength = #Files
Number = 0
NumberSub = 0
while Number ~= FilesLength do
  Number = Number + 1
  NumberSub = 0
    repeat
        NumberSub = NumberSub + 1
        if NumberSub == 1 then
          Expression = "Prototypes.Recipes.rec-" .. Files[Number]
          require(Expression)
        elseif NumberSub == 2 then
          Expression = "Prototypes.Items.item-" .. Files[Number]
          require(Expression)
        elseif NumberSub == 3 then
          Expression = "Prototypes.Technology.tech-" .. Files[Number]
          require(Expression)
        end
    until NumberSub == 3
end